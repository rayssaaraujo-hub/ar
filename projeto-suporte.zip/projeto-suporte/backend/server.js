const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/authRoutes');
const usuarioRoutes = require('./routes/usuarioRoutes');
const chamadoRoutes = require('./routes/chamadoRoutes');

const app = express();

app.use(cors());
app.use(express.json());

app.use('/', authRoutes);
app.use('/', usuarioRoutes);
app.use('/', chamadoRoutes);

app.listen(3000, () => {
  console.log('Servidor Backend rodando em http://localhost:3000');
});