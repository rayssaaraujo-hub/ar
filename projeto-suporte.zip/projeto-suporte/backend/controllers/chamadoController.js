const db = require('../config/database');

exports.listar = (req, res) => {
  const { status, prioridade } = req.query;
  let query = `
    SELECT c.*, u.nome as responsavel 
    FROM chamados c 
    JOIN usuarios u ON c.usuario_id = u.id
  `;
  const params = [];
  const conditions = [];

  if (status) {
    conditions.push(`c.status = ?`);
    params.push(status);
  }
  if (prioridade) {
    conditions.push(`c.prioridade = ?`);
    params.push(prioridade);
  }

  if (conditions.length > 0) {
    query += ` WHERE ` + conditions.join(' AND ');
  }

  query += ` ORDER BY c.id DESC`;

  db.all(query, params, (err, rows) => {
    if (err) return res.status(500).json({ mensagem: 'Erro ao buscar chamados' });
    res.status(200).json(rows);
  });
};

exports.buscarPorId = (req, res) => {
  const { id } = req.params;
  db.get(
    `SELECT c.*, u.nome as responsavel FROM chamados c JOIN usuarios u ON c.usuario_id = u.id WHERE c.id = ?`,
    [id],
    (err, row) => {
      if (err) return res.status(500).json({ mensagem: 'Erro de banco de dados' });
      if (!row) return res.status(404).json({ mensagem: 'Chamado não encontrado' });
      res.status(200).json(row);
    }
  );
};

exports.cadastrar = (req, res) => {
  const { titulo, descricao, categoria, prioridade, usuario_id } = req.body;

  if (!titulo || !descricao || !categoria || !prioridade || !usuario_id) {
    return res.status(400).json({ mensagem: 'Preencha todos os campos obrigatórios' });
  }

  db.run(
    `INSERT INTO chamados (titulo, descricao, categoria, prioridade, status, usuario_id) VALUES (?, ?, ?, ?, 'aberto', ?)`,
    [titulo, descricao, categoria, prioridade, usuario_id],
    function (err) {
      if (err) return res.status(500).json({ mensagem: 'Erro ao cadastrar chamado' });
      res.status(201).json({ id: this.lastID, mensagem: 'Chamado cadastrado' });
    }
  );
};

exports.atualizar = (req, res) => {
  const { id } = req.params;
  const { prioridade, status } = req.body;

  db.get(`SELECT * FROM chamados WHERE id = ?`, [id], (err, chamado) => {
    if (err) return res.status(500).json({ mensagem: 'Erro de banco de dados' });
    if (!chamado) return res.status(404).json({ mensagem: 'Chamado não encontrado' });

    const novaPrioridade = prioridade || chamado.prioridade;
    const novoStatus = status || chamado.status;

    db.run(
      `UPDATE chamados SET prioridade = ?, status = ? WHERE id = ?`,
      [novaPrioridade, novoStatus, id],
      function (err) {
        if (err) return res.status(500).json({ mensagem: 'Erro ao atualizar' });
        res.status(200).json({ mensagem: 'Chamado atualizado com sucesso' });
      }
    );
  });
};

exports.excluir = (req, res) => {
  const { id } = req.params;
  db.run(`DELETE FROM chamados WHERE id = ?`, [id], function (err) {
    if (err) return res.status(500).json({ mensagem: 'Erro ao excluir' });
    if (this.changes === 0) return res.status(404).json({ mensagem: 'Chamado não encontrado' });
    res.status(200).json({ mensagem: 'Chamado excluído com sucesso' });
  });
};