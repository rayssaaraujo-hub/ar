const db = require('../config/database');
const bcrypt = require('bcryptjs');

exports.cadastrar = (req, res) => {
  const { nome, email, senha, perfil } = req.body;

  if (!nome || !email || !senha || !perfil) {
    return res.status(400).json({ mensagem: 'Todos os campos são obrigatórios' });
  }

  const hashSenha = bcrypt.hashSync(senha, 8);

  db.run(
    `INSERT INTO usuarios (nome, email, senha, perfil) VALUES (?, ?, ?, ?)`,
    [nome, email, hashSenha, perfil],
    function (err) {
      if (err) {
        if (err.message.includes('UNIQUE')) {
          return res.status(400).json({ mensagem: 'E-mail já cadastrado' });
        }
        return res.status(500).json({ mensagem: 'Erro ao cadastrar usuário' });
      }
      res.status(201).json({ id: this.lastID, nome, email, perfil });
    }
  );
};

exports.listar = (req, res) => {
  db.all(`SELECT id, nome, email, perfil FROM usuarios`, [], (err, rows) => {
    if (err) return res.status(500).json({ mensagem: 'Erro ao buscar usuários' });
    res.status(200).json(rows);
  });
};