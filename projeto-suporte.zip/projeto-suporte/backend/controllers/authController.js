const db = require('../config/database');
const bcrypt = require('bcryptjs');

exports.login = (req, res) => {
  const { email, senha } = req.body;

  if (!email || !senha) {
    return res.status(400).json({ mensagem: 'E-mail e senha são obrigatórios' });
  }

  db.get(`SELECT * FROM usuarios WHERE email = ?`, [email], (err, user) => {
    if (err) return res.status(500).json({ mensagem: 'Erro de banco de dados' });
    if (!user) return res.status(401).json({ mensagem: 'Credenciais inválidas' });

    const senhaValida = bcrypt.compareSync(senha, user.senha);
    if (!senhaValida) return res.status(401).json({ mensagem: 'Credenciais inválidas' });

    res.status(200).json({
      mensagem: 'Usuário autenticado com sucesso',
      usuario: { id: user.id, nome: user.nome, email: user.email, perfil: user.perfil }
    });
  });
};