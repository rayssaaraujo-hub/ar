const db = require('./config/database');
const bcrypt = require('bcryptjs');

const senhaHash = bcrypt.hashSync('123456', 8);

db.run(
  `INSERT OR IGNORE INTO usuarios (nome, email, senha, perfil) VALUES (?, ?, ?, ?)`,
  ['Administrador', 'admin@teste.com', senhaHash, 'admin'],
  function (err) {
    if (err) console.error('Erro ao criar usuário:', err.message);
    else console.log('Usuário padrão criado com sucesso!');
  }
);